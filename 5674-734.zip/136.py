f = lambda x: x*x
args = [1, 2, 3, 4, 5]
ret = map(f, args)
print(list(ret))
