bool1 = True; bool2 = False; bool3 = True; bool4 = False
print(bool1 and bool2)    # False가 출력됨
print(bool1 and bool3)    # True가 출력됨
print(bool2 or bool3)     # True가 출력됨
print(bool2 or bool4)     # False가 출력됨
print(not bool1)          # False가 출력됨
print(not bool2)          # True가 출력됨
