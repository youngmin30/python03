listdata = list(range(3))
ret = listdata*3
print(ret)   # [0, 1, 2, 0, 1, 2, 0, 1, 2]가 출력됨
