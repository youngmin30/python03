idata1 = int(-5.4)
idata2 = int(1.78e1)
idata3 = int(171.56)
print(idata1)   # -5가 출력됨
print(idata2)   # 17이 출력됨
print(idata3)   # 171이 출력됨
