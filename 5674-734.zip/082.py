msg = input('임의의 문장을 입력하세요: ')
if 'is' in msg:
   print('당신이 입력한 문장에는 is가 있습니다.')
else:
   print('당신이 입력한 문장에는 is가 없습니다.')
