print('안녕하세요')
a = 1
b = 1
print(a+b)
