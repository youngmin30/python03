abs1 = abs(-3)        # 정수의 절대값
abs2 = abs(-5.72)      # 실수의 절대값
abs3 = abs(3+4j)      # 복소수의 절대값
print(abs1)       # 3이 출력됨
print(abs2)       # 5.72가 출력됨
print(abs3)       # 5.0이 출력됨
