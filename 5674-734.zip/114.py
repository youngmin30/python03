listdata = [2, 2, 1, 3, 8, 5, 7, 6, 3, 6, 2, 3, 9, 4, 4]
listsize = len(listdata)
print(listsize)   # 15가 출력됨
