num1 = 1234
num2 = 3.14

numstr1 = str(num1)
numstr2 = str(num2)
print('num1을 문자열로 변환한 값은 “%s” 입니다.' %numstr1)
print('num2를 문자열로 변환한 값은 “%s” 입니다.' %numstr2)
