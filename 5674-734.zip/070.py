fdata = float(10)
print(fdata)   # 10.0으로 출력됨
