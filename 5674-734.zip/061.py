numdata = 57
strdata = '파이썬'
listdata = [1, 2, 3]
dictdata = {'a':1, 'b':2}

def func():
   print('안녕하세요.')

print(type(numdata))
print(type(strdata))
print(type(listdata))
print(type(dictdata))
print(type(func))
