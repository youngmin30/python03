txt1 = 'A tale that was not right'
txt2 = '이 또한 지나가리라.'
print(txt1[5])      # ‘e’가 출력됨
print(txt2[-2])     # ‘다’가 출력됨
