x = 1
y = 2

if x >= y:
    print('x가 y보다 크거나 같습니다.')
else:
    print('x가 y보다 작습니다.')
