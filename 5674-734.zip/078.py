txt = 'abcdefghijk'
ret = txt[::-1]
print(ret)       # ‘kjihgfedcba’ 가 출력됨
