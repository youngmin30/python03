listdata = list(range(1, 21))
evenlist = listdata[1::2]
print(evenlist)
