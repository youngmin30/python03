listdata = [2, 2, 1, 3, 8, 5, 7, 6, 3, 6, 2, 3, 9, 4, 4]
c1 = listdata.count(2)
c2 = listdata.count(7)
print(c1)    # 3이 출력됨
print(c2)    # 1이 출력됨
