ret1 = round(1118)    # 소수점 첫째자리에서 반올림해줌
ret2 = round(16.554)    # 소수점 첫째자리에서 반올림해줌
ret3 = round(1118, -1)  # 1자리에서 반올림해줌
ret4 = round(16.554, 2)  # 소수점 셋째자리에서 반올림해줌
print(ret1)   # 1118
print(ret2)   # 17
print(ret3)   # 1120
print(ret4)   # 16.55
