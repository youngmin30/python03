try:
   print('안녕하세요.')
   print(param)
except:
   print('예외가 발생했습니다!')
else:
   print('예외가 발생하지 않았습니다.')
