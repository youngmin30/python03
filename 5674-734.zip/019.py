a = 1
b = 2
ret = a+b
print('a와 b를 더한 값은 ', end='')
print(ret, end='')
print(' 입니다')
