artist = '빅뱅'
sing = '뱅~'
dispdata = artist + '이 부르는 ' + sing*3
print(dispdata)  # ‘빅뱅이 부르는 뱅~뱅~뱅~’이 출력됨
