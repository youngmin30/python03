listdata = list(range(5))
listdata.reverse()
print(listdata)  # [4, 3, 2, 1, 0]이 출력됨
