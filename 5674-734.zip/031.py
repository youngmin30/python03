strdata1 = 'I love python'
strdata2 = '나는 파이썬을 사랑합니다'
listdata = ['a', 'b', 'c', strdata1, strdata2]
print(len(strdata1))    # 13이 출력됨
print(len(strdata2))    # 13이 출력됨
print(len(listdata))     # 5가 출력됨
print(len(listdata[3]))  # 13이 출력됨
