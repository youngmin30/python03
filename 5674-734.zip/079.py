filename = input('저장할 파일 이름을 입력하세요: ')
filename = filename + '.jpg'
display_msg = '당신이 저장한 파일은 <' + filename + '> 입니다.'
print(display_msg)
