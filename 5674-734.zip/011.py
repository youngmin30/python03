scope = [1, 2, 3, 4, 5]
for x in scope:
    print(x)
