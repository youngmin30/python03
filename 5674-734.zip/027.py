strdata = 'Time is money!!'
listdata = [1, 2, [1, 2, 3]]
print(strdata[5])     # ‘i'가 출력됨
print(strdata[-2])    # ‘!’가 출력됨
print(listdata[0])     # 1이 출력됨
print(listdata[-1])    # [1, 2, 3]이 출력됨
print(listdata[2][-1])  # 3이 출력됨
