f = open('stockcode.txt', 'r')
data = f.read()
print(data)
f.close()
