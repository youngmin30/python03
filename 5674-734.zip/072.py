listdata = [9.96, 1.27, 5.07, 6.45, 8.38, 9.29, 4.93, 7.73, 3.71, 0.93]
maxval = max(listdata)
minval = min(listdata)
print(maxval)     # 9.96이 출력됨
print(minval)     # 0.93이 출력됨

txt = 'Alotofthingsoccureachday'
maxval = max(txt)
minval = min(txt)
print(maxval);     # ‘y’가 출력됨
print(minval)     # ‘A’가 출력됨

maxval = max(2+3, 2*3, 2**3, 3**2)
minval = min('abz', 'a12')
print(maxval)    # 9가 출력됨
print(minval)     # ‘abz’가 출력됨
